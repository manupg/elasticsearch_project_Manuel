

import requests
import json
import time
from pprint import pprint
import urllib2
import sys

#PRIMERA CARGA

num_eventos = raw_input("introduce el numero de eventos por pagina: ")

#Se el ETAG de la primera, asi como el ID del primer evento de la primera pagina. 
#Esto evitara cargar eventos repetidos

num_paginas=300/int(num_eventos)
print("Numero de eventos: " + num_eventos+","+"Numero de pagins: " + str(num_paginas))
opener = urllib2.build_opener(urllib2.HTTPHandler)
url="http://localhost:9200/logstash-github/"


for i in range(num_paginas):

	
	datos= requests.get('https://api.github.com/events?per_page='+num_eventos
			    +'+&page='+str(i),auth=('manupg', 'volvagia9'))

	jsona=datos.json()

	if i == 1:

		id_evento=jsona[0]["id"]

	fichero=open("github.json","a")

	for i in range(len(jsona)):
		
		data_json = json.dumps(jsona[i])
		url_ela=url+jsona[i]["type"]+"/"+jsona[i]["id"]
		request = urllib2.Request(url_ela, data=data_json)
            	request.get_method = lambda: 'PUT'
            	response = opener.open(request)
		
#CARGAS SIGUIENTES

while True:
##comienzo bucle
	
	quit=False
	
	for i in range(num_paginas):
	
		datos= requests.get('https://api.github.com/events?per_page='+num_eventos
				    +'+&page='+str(i),auth=('manupg','volvagia9'))

		print("SE PROCESA LA PAGINA "+str(i+1))
		jsona= datos.json()
		fichero=open("github.json","a")

		for i in range(len(jsona)):
			if jsona[i]["id"] != id_evento:
				
				data_json = json.dumps(jsona[i])
				url_ela=url+jsona[i]["type"]+"/"+jsona[i]["id"]
				request = urllib2.Request(url_ela, data=data_json)
            			request.get_method = lambda: 'PUT'
            			response = opener.open(request)
				
			else:
				print("EVENTO REPETIDO, NO SE GUARDA A PARTIR DE AQUI: " 
				      + jsona[i]["id"] +"=" + id_evento  )
				quit=True
				break
		fichero.close()
		print ("Eventos cargados de esta pagina ==> "+ str(i+1) + "\n")
		print ("Eventos repetidos de esta pagina ==> "+ str(99-i) + "\n")
			
		if quit==True:
			break
##ahora guardamos el primer evento de la nueva primera pagina, ya que hasta ese evento, todos han sido cargados.
	id_evento=jsona[0]["id"]
	fichero=open("ultimo_id.txt","w")
	fichero.write(id_evento)
	fichero.close()
##fin bucle

