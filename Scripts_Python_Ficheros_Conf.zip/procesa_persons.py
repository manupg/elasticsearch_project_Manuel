

import json

from pprint import pprint

with open("scm-persons.json") as data_file:
	data=json.load(data_file)


fichero= open("persons_procesado.json","a")
for i in range(len(data["values"])):
	fichero.write(json.dumps({data["names"][0]:data["values"][i][0],data["names"][1]:data["values"][i][1],data["names"][2]:data["values"][i][2],"per_id":data["values"][i][3]}, sort_keys=True))
	fichero.write("\n");
fichero.close()



