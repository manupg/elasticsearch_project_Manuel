

import json

from pprint import pprint

with open("scm-commits-distinct.json") as data_file:
	data=json.load(data_file)


fichero= open("commits_procesado.json","a")
for i in range(len(data["values"])):
	fichero.write(json.dumps({data["names"][0]:data["values"][i][0],data["names"][1]:data["values"][i][1],data["names"][2]:data["values"][i][2],data["names"][3]:data["values"][i][3],data["names"][4]:int(data["values"][i][4]),data["names"][5]:data["values"][i][5],data["names"][6]:data["values"][i][6],data["names"][7]:data["values"][i][7],data["names"][8]:data["values"][i][8]}, sort_keys=True))
	fichero.write("\n");
fichero.close()


