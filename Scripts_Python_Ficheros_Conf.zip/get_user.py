

import requests
import json
import time
from pprint import pprint
import urllib2
import github3

opener = urllib2.build_opener(urllib2.HTTPHandler)
url="http://localhost:9200/github-users/"	
g = github3.login(username = 'manupg', password = 'volvagia9')
i = 0
for user in g.all_users(per_page=100):
	user.refresh()
	coordinatess = "";
	city = "";
	if user.location is not None and user.location != "":
		if "," in user.location:
			city = user.location.split(",")[0]
		else:
			city = user.location
	print city
	if city != "":
		GeoData = requests.get('http://nominatim.openstreetmap.org/search?city='+city+'&format=json').json()
		#print (GeoData)
		if len(GeoData) > 0:

			coordinates = GeoData[0]["lat"] + ","+ GeoData[0]["lon"]
		

	data = {'name': user.name, 'email' :user.email,'company':user.company, 'location': user.location,'coordinates':coordinates}
	#print (str(json.loads(user.as_json()).append({'location':user.location})))
	jsona =json.dumps(data)
	string= json.loads(jsona)
	print (json.dumps(string))
	#print str(" se carga el usuario:"+ jsona)
	url_ela=url+"usuarios"+"/"+str(user.id)
	
	#print(url_ela)
	request = urllib2.Request(url_ela, data=json.dumps(string))
        request.get_method = lambda: 'PUT'
        response = opener.open(request)



