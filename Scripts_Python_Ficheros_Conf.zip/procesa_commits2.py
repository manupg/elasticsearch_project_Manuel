import math

import json

from pprint import pprint
import datetime


with open("scm-commits.json") as data_file:
	data=json.load(data_file)

print(data["values"][655][1])
print("\n")
print(data["values"][655][2])
print("\n")
print(data["values"][655][3])

fichero= open("commits2_procesado.json","a")
for i in range(len(data["values"])):
	
	if math.isnan(data["values"][i][2]):
		data["values"][i][2]=0
		
	fichero.write(json.dumps({data["names"][0]:data["values"][i][0],data["names"][1]:datetime.datetime.fromtimestamp(int(data["values"][i][1])).strftime('%Y-%m-%dT%H:%M:%S'),"per_id":int(data["values"][i][2]),"org_id":int(data["values"][i][3]),"repo_id":data["values"][i][4],data["names"][5]:data["values"][i][5]}, sort_keys=True))
	fichero.write("\n");
fichero.close()


